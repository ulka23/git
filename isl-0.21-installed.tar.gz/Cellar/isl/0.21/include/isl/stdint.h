#ifndef _ISL_INCLUDE_ISL_STDINT_H
#define _ISL_INCLUDE_ISL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "isl 0.21"
/* generated using gnu compiler Apple LLVM version 10.0.1 (clang-1001.0.46.4) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
